#!/usr/bin/env python
# coding: utf-8

# In[21]:


#1.WAP to check whether a character is alphabet or not
sr=(input("Enter a character:"))
if(sr>='a' and sr<='z') or (sr>='A' and sr<='Z'):
    print("It's alphabet")
else:
    print("It's not an alphabet")


# In[11]:


#2.WAP to check wheter a number is negative ,positive or zero
num=int(input("Enter number:"))
if(num>0):
    print("Number is positive")
elif(num<0):
    print("Number is negative")
else:
    print("Zero")


# In[19]:


#3. WAP to check login and password
lgn='user123'
password='user#@13'
u_login=input("Enter ur login:")
u_pass=input("Enter ur password:")
if u_login==lgn and u_pass==password:
    print("succefull")
else:
    print("Invalid")


# In[24]:


# 4.WAP to check if the user has provided the correct currency note for deposite or not
        # a.The note should be in b/w the following currencies:
            # i> 2000,500,200,100,50
        
cur=int(input("Enter currency:"))
if cur==2000 or cur==500 or cur==200 or cur==100 or cur==50:
    print("Valid currency")
else:
    print("Invalid currency! not accepted")
   


# In[37]:


#5. WAP to check whether a character is alphabet ,number or special character
un=input("Enter input:")
if (un>='a' and un>='z') and (un>='A'or un>='Z'):
    print("It's an alphabet")
elif(un>='0' and un<='9'):
    print("It's a number")
else:
    print("Special symbol")
    





# In[11]:


#6. Input units of electricity from user and print the bill according to the following criteria:
                # a> less tha 200: no bill
                # b> 200-300 - 1/perunit  
                # c> 300-400 - 2/perunit 
                # d> 400-500 - 3/perunit
                # e> Above 500 -8/perUnit
#             Units=590
# Bill=((590-500)*8)+100*3+100*2+100*1
# Bill=720+300+200+100=1320

Bin=int(input("Enter unit:"))
if(Bin<200):
    print("No Bill")
elif(Bin>=200 and Bin<300):
    Bill=(Bin-200)*1
    print("Your bill",Bill)
elif(Bin>=300 and Bin<400):
    Bill=100*1+(Bin-300)*2
    print("Your Bill",Bill)
elif(Bin>=400 and Bin<=500):
    Bill=(Bin-300)*3+300*1
    print("Your Bill",Bill)
elif(Bin>500):
    Bill=(Bin-500)*8+(500-400)*3+(400-300)*2+100*1
    print("Your Bill",Bill)
    
else:
    print("invalid")
            


# In[ ]:





# In[ ]:




