#!/usr/bin/env python
# coding: utf-8

# 
# Q.1 Write a program for arithmatic operators
# 
# Q.2 Write a program for assignment operators
# 
# Q.3Write a program for Bitwise operators 
# 
# Q.4 Write a program to calculate greatest of three numbers.
# 
# 1.      Calculate the area of a circle.
# 
# 2.      Calculate the area of a triangle.
# 
# 3.      Calculate the area of a rectangle.
# 
# 4.      Calculate the area of a square.

# In[5]:


# Q1 Write a program for arithmatic operators
a=10
b=20
print('A=',a)
print('B',b)
print('Addition=',a+b)
print('Subtraction=',a-b)
print('Multiplication=',a*b)
print("Division=",a/b)
print("Modulus=",a%b)


# In[12]:


# Q.2 Write a program for assignment operators
a=10
print('A=',a)
a+=7
print('use of +=7->',a)
a-=3
print('use of -=3->',a)
a*=2
print('use of *=2->',a)
a/=2
print('use of /=2->',a)


# In[ ]:


# Q.3Write a program for Bitwise operators 


# In[13]:


# Q.4 Write a program to calculate greatest of three numbers.

a=input("Enter 1st number:")
b=input("Enter 1st number:")
c=input("Enter 1st number:")
if(a>b and a>c):
    print('Greatest number=',a)
elif(b>c and b>a):
    print('Greatest number=',b)
else:
    print('Greatest number=',c)



# In[16]:


# 1.      Calculate the area of a circle.

c=float(input("Enter radius of circel="))
Ac=3.14*3.14*c
print('Area of circle=',Ac)


# In[19]:


# 2. Calculate the area of a triangle.
base=float(input('Enter base of triangle'))
height=float(input('Enter height of triangle'))
areaOfTriangle=0.5*base*height
print("Area of Triangle=",areaOfTriangle)


# In[20]:


# 3. Calculate the area of a rectangle.
ln=float(input('Enter length'))
wd=float(input('Enter width'))
areaOfrectangle=ln*wd
print('Area of rectangle=',areaOfrectangle)


# In[22]:


#  4.Calculate the area of a square.
side=float(input('Enter side of square:'))
AreaOfSquare=side*side
print('Area Of Square=',AreaOfSquare)


# In[ ]:





# In[ ]:




