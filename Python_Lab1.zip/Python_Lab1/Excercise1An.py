#!/usr/bin/env python
# coding: utf-8

# Solve any two questions
# 
# Q.1 print helloworld
# 
# Q.2 describe local variable and global variable code
# 
# Q.3 Write a code that describe Indentation error
# 
# Q.4 write a code that describe local and global variable with same name
# 
# Q.5 Write a code for string, int and float input.
# 
# 
# 

# In[1]:


# Q1

print("Hello World")


# Q2
# 
# **Local Variable**:-Local variables are the variables defined within a function. They are only accessible within the function where they are defined.
# 
# 
# **Global Variable**:-Global variables are defined outside of any function and can be accessed throughout the program, both inside and outside of functions.

# In[2]:


# Q3

if x==7:
print("x=",x)
else:
    print("non")


# In[9]:


# Q4

# global
x=7
def printx():
    x=9
    print('Inside function x=',x)
print('X as global function x=',x)
printx()


# In[11]:


# Q5
st=str(input("Enter string input"))
print('Your string:-',st)
it=int(input("Enter integer input"))
print('Your integer:-',it)
fl=float(input("Enter float input"))
print('Your float:-',fl)

